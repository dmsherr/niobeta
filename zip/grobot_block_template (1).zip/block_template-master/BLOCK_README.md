Example
===========

What does this block do?

Properties
--------------
None

Dependencies
----------------
None

Commands
----------------
None

Input
-------
Any list of signals.

Output
---------
Same list of signals as input.
